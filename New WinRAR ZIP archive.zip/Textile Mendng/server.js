const express = require('express');
const app = express();
const nodemailer = require('nodemailer');

// Middleware to parse incoming form data
app.use(express.urlencoded({ extended: false }));

// POST route for password reset form submission
app.post('/reset-password', (req, res) => {
  const email = req.body.email;

  // Perform email validation and additional logic here

  // Send password reset email
  sendPasswordResetEmail(email)
    .then(() => {
      res.send('Password reset email sent.');
    })
    .catch((error) => {
      console.error('Error sending password reset email:', error);
      res.status(500).send('An error occurred while sending the password reset email.');
    });
});

// Function to send the password reset email using nodemailer
function sendPasswordResetEmail(email) {
  return new Promise((resolve, reject) => {
    // Create a nodemailer transporter using your email service provider settings
    const transporter = nodemailer.createTransport({
      // Configuration options (e.g., SMTP credentials)
    });

    // Define the email options
    const mailOptions = {
      from: 'your-email@example.com',
      to: email,
      subject: 'Password Reset',
      text: 'Please follow the instructions to reset your password.',
    };

    // Send the email
    transporter.sendMail(mailOptions, (error) => {
      if (error) {
        reject(error);
      } else {
        resolve();
      }
    });
  });
}

// Start the server
app.listen(3000, () => {
  console.log('Server is running on port 3000');
});
